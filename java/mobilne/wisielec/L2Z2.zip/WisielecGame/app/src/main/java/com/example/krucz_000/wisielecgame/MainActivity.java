package com.example.krucz_000.wisielecgame;

import android.os.BaseBundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    String[] words;
    int numberTries;
    String generatedWord;
    String hiddenWord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        words = getResources().getStringArray(R.array.words);
        numberTries=0;
        generateNewWord();
    }

    private void changeImage() {
        ImageView img = (ImageView) findViewById(R.id.imageView3);
        switch (numberTries){
            case 0:
                img.setImageResource(R.drawable.wisielec0);
                break;
            case 1:
                img.setImageResource(R.drawable.wisielec1);
                break;
            case 2:
                img.setImageResource(R.drawable.wisielec2);
                break;
            case 3:
                img.setImageResource(R.drawable.wisielec3);
                break;
            case 4:
                img.setImageResource(R.drawable.wisielec4);
                break;
            case 5:
                img.setImageResource(R.drawable.wisielec5);
                break;
            case 6:
                img.setImageResource(R.drawable.wisielec6);
                break;
            case 7:
                img.setImageResource(R.drawable.wisielec7);
                break;
            case 8:
                img.setImageResource(R.drawable.wisielec8);
                break;
            case 9:
                img.setImageResource(R.drawable.wisielec9);
                break;
            case 10:
                img.setImageResource(R.drawable.wisielec10);
                break;
            case 11:
                img.setImageResource(R.drawable.wisielec11);
                break;
            default:


        }
    }


    private void generateNewWord() {
        Random rand = new Random();
        int pos=rand.nextInt(14718);
        TextView txt= (TextView) findViewById(R.id.textView);
        generatedWord=words[pos];
        hiddenWord="";
        for (int i=0;i<generatedWord.length();i++){
            hiddenWord+="*";
        }
        txt.setText(hiddenWord);
        changeImage();
    }

    public void check(View view) {
        EditText edit= (EditText) findViewById(R.id.editText);
        String letter= edit.getText().toString().toLowerCase();
        TextView txt= (TextView) findViewById(R.id.textView);
        edit.setText("");

        if (!letter.isEmpty()){
                boolean found= false;
                for (int i=0;i<generatedWord.length();i++){
                    if (generatedWord.substring(i,i+1).equals(letter)){
                        found=true;
                        replaceAt(letter);
                    }
                }
                if (!found){
                    numberTries++;
                    changeImage();
                    if (numberTries>10){
                        TextView txt2= (TextView) findViewById(R.id.textView2);
                        txt2.setText("PRZEGRAŁEŚ!!!");
                        txt.setText(generatedWord);
                        Button but= (Button) findViewById(R.id.button1);
                        but.setEnabled(false);
                    }
                }else{
                    checkWin();
                }
        }
    }

    private void checkWin() {
        boolean win=false;
        if(generatedWord.equalsIgnoreCase(hiddenWord)) {
            win = true;
        }
        if (win){
            TextView txt= (TextView) findViewById(R.id.textView2);
            txt.setText("WYGRAŁEŚ!!!");
            Button but= (Button) findViewById(R.id.button1);
            but.setEnabled(false);
        }
    }

    private void replaceAt(String letter) {
        String newword="";
        for (int i=0;i<hiddenWord.length();i++){
            if (generatedWord.substring(i,i+1).equals(letter)){
                newword+=letter;
            }else{
                newword+=hiddenWord.substring(i,i+1);
            }
        }
        hiddenWord=newword;
        TextView txt= (TextView) findViewById(R.id.textView);
        txt.setText(hiddenWord);

    }

    public void nextWord(View view) {
        numberTries=0;
        generateNewWord();
        TextView txt= (TextView) findViewById(R.id.textView2);
        txt.setText("Wprowadź kolejną literę:");
        Button but= (Button) findViewById(R.id.button1);
        but.setEnabled(true);
    }



}
