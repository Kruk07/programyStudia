package com.example.krucz_000.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Quit(View view) {
        this.finishAndRemoveTask();
    }

    public void vsComputer(View view) {
        Context context = getApplicationContext();
        Intent intent = new Intent(context,GameActivity.class);
        intent.putExtra("type","computer");
        startActivity(intent);
    }

    public void vsPlayer(View view) {
        Context context = getApplicationContext();
        Intent intent = new Intent(context,GameActivity.class);
        intent.putExtra("type","player");
        startActivity(intent);
    }
}
