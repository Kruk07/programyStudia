package com.example.krucz_000.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class GameActivity extends AppCompatActivity {

    boolean isAble;
    boolean computer;
    int[][] table = new int[4][4];
    int [] lastmove= new int[2];
    int [] possibleResult=new int[2];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        Intent i=getIntent();
        String typ = i.getStringExtra("type");
        if(typ.contains("player")){
            computer=false;
        }else{
            computer=true;
        }
        TextView txt = (TextView)findViewById(R.id.textView);
        isAble=true;
        for(int j=0;j<4;j++){
            for(int k=0;k<4;k++){
                table[j][k]=0;
            }
        }
        lastmove[0]=0;
        lastmove[1]=0;
        possibleResult[0]=-1;
        possibleResult[1]=-1;
    }


    public void mark(View view) {

        String name = getResources().getResourceEntryName(view.getId());
        Button btn = (Button) findViewById(view.getId());

        int paramx=Integer.parseInt(name.substring(3,4));
        int paramy=Integer.parseInt(name.substring(4,5));
        lastmove[0]=paramx;
        lastmove[1]=paramy;
        TextView txt = (TextView)findViewById(R.id.textView);
        if (isAble){
            btn.setText("X");
            isAble=false;
            table[paramx][paramy]=1;
            txt.setText("Ruch gracza 2");
        }else{
            btn.setText("O");
            isAble=true;
            table[paramx][paramy]=2;

            txt.setText("Ruch gracza 1");
        }
        btn.setClickable(false);

        if (checkWin()){
            if(isAble){
                Context context = getApplicationContext();
                CharSequence text = "Wygrał gracz 2";
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                disableAllButtons();
                txt.setText("Wygrał gracz 2");
                return;
            }else{
                Context context = getApplicationContext();
                CharSequence text = "Wygrał gracz 1";
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                disableAllButtons();
                txt.setText("Wygrał gracz 1");
                return;
            }
        }else{
            boolean isAll=true;
            for (int i=0;i<4;i++){
                for(int j=0;j<4;j++){
                    if(table[i][j]==0){
                        isAll=false;
                        break;
                    }
                }
            }
            if(isAll){
                Context context = getApplicationContext();
                CharSequence text = "Remis";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                disableAllButtons();
                txt.setText("Remis");
                return;
            }
        }
        
        if(computer){
            makemove();
            isAble=true;
            txt.setText("Ruch gracza 1");
            if (checkWin()){
                Context context = getApplicationContext();
                CharSequence text = "Wygrał komputer";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                disableAllButtons();
                txt.setText("Wygrał komputer");
                return;
            }else{
                boolean isAll=true;
                for (int i=0;i<4;i++){
                    for(int j=0;j<4;j++){
                        if(table[i][j]==0){
                            isAll=false;
                            break;
                        }
                    }
                }
                if(isAll){
                    Context context = getApplicationContext();
                    CharSequence text = "Remis";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    disableAllButtons();
                    txt.setText("Remis");
                    return;
                }
            }
        }


    }

    private Button getButton(int i,int j){
        if (i==0&&j==0){
            Button but=(Button) findViewById(R.id.but00);
            return but;
        }else
        if (i==0&&j==1){
            Button but=(Button) findViewById(R.id.but01);
            return but;
        }else
        if (i==0&&j==2){
            Button but=(Button) findViewById(R.id.but02);
            return but;
        }else
        if (i==0&&j==3){
            Button but=(Button) findViewById(R.id.but03);
            return but;
        }else
        if (i==1&&j==0){
            Button but=(Button) findViewById(R.id.but10);
            return but;
        }else
        if (i==1&&j==1){
            Button but=(Button) findViewById(R.id.but11);
            return but;
        }else
        if (i==1&&j==2){
            Button but=(Button) findViewById(R.id.but12);
            return but;
        }else
        if (i==1&&j==3){
            Button but=(Button) findViewById(R.id.but13);
            return but;
        }else
        if (i==2&&j==0){
            Button but=(Button) findViewById(R.id.but20);
            return but;
        }else
        if (i==2&&j==1){
            Button but=(Button) findViewById(R.id.but21);
            return but;
        }else
        if (i==2&&j==2){
            Button but=(Button) findViewById(R.id.but22);
            return but;
        }else
        if (i==2&&j==3){
            Button but=(Button) findViewById(R.id.but23);
            return but;
        }else
        if (i==3&&j==0){
            Button but=(Button) findViewById(R.id.but30);
            return but;
        }else
        if (i==3&&j==1){
            Button but=(Button) findViewById(R.id.but31);
            return but;
        }else
        if (i==3&&j==2){
            Button but=(Button) findViewById(R.id.but32);
            return but;
        }else
        if (i==3&&j==3){
            Button but=(Button) findViewById(R.id.but33);
            return but;
        }else{
            return null;
        }

    }
    private void makemove() {
        Random rand=new Random();
        int number1=-1;
        int number2=-1;

        boolean valid=false;
        boolean checkSenseMove=false;
        while (!valid){
            int x=lastmove[0];
            int y=lastmove[1];
            if(!checkSenseMove){
                boolean findCross=findCrosses(2);
                if(findCross&&isValid(possibleResult[0],possibleResult[1])){
                    number1=possibleResult[0];
                    number2=possibleResult[1];
                    valid=isValid(number1,number2);
                }else{
                    boolean findLines=findLines(2);
                    if (findLines&&isValid(possibleResult[0],possibleResult[1])){
                        number1=possibleResult[0];
                        number2=possibleResult[1];
                        valid=isValid(number1,number2);
                    }else{
                        boolean findColumns=findColumns(2);
                        if (findColumns&&isValid(possibleResult[0],possibleResult[1])){
                            number1=possibleResult[0];
                            number2=possibleResult[1];
                            valid=isValid(number1,number2);
                        }else{
                            boolean attackcrosses=findCrosses(1);
                            if (attackcrosses&&isValid(possibleResult[0],possibleResult[1])){
                                number1=possibleResult[0];
                                number2=possibleResult[1];
                                valid=isValid(number1,number2);
                            }else{
                                boolean attackcolumns=findColumns(1);
                                if(attackcolumns&&isValid(possibleResult[0],possibleResult[1])){
                                    number1=possibleResult[0];
                                    number2=possibleResult[1];
                                    valid=isValid(number1,number2);
                                }else{
                                    boolean attacklines=findLines(1);
                                    if(attacklines&&isValid(possibleResult[0],possibleResult[1])){
                                        number1=possibleResult[0];
                                        number2=possibleResult[1];
                                        valid=isValid(number1,number2);
                                    }else{
                                        checkSenseMove=true;
                                    }
                                }
                            }
                        }
                    }
                }

            }else{
                number1=rand.nextInt(4);
                number2=rand.nextInt(4);
                valid=isValid(number1,number2);
            }
        }
        Button but=getButton(number1,number2);
        but.setText("O");
        table[number1][number2]=2;
        but.setClickable(false);
    }


    private boolean findColumns(int player) {
        int sum=0;
        int last1=0;
        int last2=0;
        for (int i=0;i<4;i++){
            sum=0;
            for (int j=0;j<4;j++){
                if(table[j][i]==player){
                    sum++;
                }
                if(table[j][i]==0){
                    last1=j;
                    last2=i;
                }
            }
            if (sum==3){
                possibleResult[0]=last1;
                possibleResult[1]=last2;
                if(isValid(last1,last2)){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean findLines(int player) {
        int sum=0;
        int last1=0;
        int last2=0;
        for (int i=0;i<4;i++){
            sum=0;
            for (int j=0;j<4;j++){
                if(table[i][j]==player){
                    sum++;
                }
                if(table[i][j]==0){
                    last1=i;
                    last2=j;
                }
            }
            if (sum==3){
                possibleResult[0]=last1;
                possibleResult[1]=last2;
                if(isValid(last1,last2)){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean findCrosses(int player) {
        int sum=0;
        int last=0;
        for (int i=0;i<4;i++){
            if(table[i][i]==player){
                sum++;
            }
            if(table[i][i]==0){
                last=i;
            }
        }
        if (sum==3){
            possibleResult[0]=last;
            possibleResult[1]=last;
            if(isValid(last,last)){
                return true;
            }
        }
        sum=0;
        int last1=0;
        int last2=0;
        for (int i=0;i<4;i++){
            if(table[i][3-i]==player){
                sum++;
            }
            if(table[i][3-i]==0){
                last1=i;
                last2=3-i;
            }
        }
        if (sum==3){
            possibleResult[0]=last1;
            possibleResult[1]=last2;
            if(isValid(last1,last2)){
                return true;
            }
        }
        return false;
    }

    private boolean isValid(int number1,int number2) {
        if (number1>3||number1<0||number2>3||number2<0){
            return false;
        }
        if(table[number1][number2]==0){
            return true;
        }else{
            return false;
        }
    }

    private void disableAllButtons() {
        Button but00=(Button) findViewById(R.id.but00);
        Button but01=(Button) findViewById(R.id.but01);
        Button but02=(Button) findViewById(R.id.but02);
        Button but03=(Button) findViewById(R.id.but03);
        Button but10=(Button) findViewById(R.id.but10);
        Button but11=(Button) findViewById(R.id.but11);
        Button but12=(Button) findViewById(R.id.but12);
        Button but13=(Button) findViewById(R.id.but13);
        Button but20=(Button) findViewById(R.id.but20);
        Button but21=(Button) findViewById(R.id.but21);
        Button but22=(Button) findViewById(R.id.but22);
        Button but23=(Button) findViewById(R.id.but23);
        Button but30=(Button) findViewById(R.id.but30);
        Button but31=(Button) findViewById(R.id.but31);
        Button but32=(Button) findViewById(R.id.but32);
        Button but33=(Button) findViewById(R.id.but33);
        but00.setEnabled(false);
        but01.setEnabled(false);
        but02.setEnabled(false);
        but03.setEnabled(false);
        but10.setEnabled(false);
        but11.setEnabled(false);
        but12.setEnabled(false);
        but13.setEnabled(false);
        but20.setEnabled(false);
        but21.setEnabled(false);
        but22.setEnabled(false);
        but23.setEnabled(false);
        but30.setEnabled(false);
        but31.setEnabled(false);
        but32.setEnabled(false);
        but33.setEnabled(false);
    }

    private boolean checkWin() {

        boolean win=false;

        if(table[0][0]==table[1][1]&&table[1][1]==table[2][2]&table[2][2]==table[3][3]
                &&table[0][0]!=0&&table[1][1]!=0&&table[2][2]!=0&&table[3][3]!=0){
            //wygrana
            win=true;
        }
        if(table[3][0]==table[2][1]&&table[2][1]==table[1][2]&&table[1][2]==table[0][3]
                &&table[3][0]!=0&&table[2][1]!=0&&table[1][2]!=0&&table[0][3]!=0){
            //wygrana
            win=true;
        }
        if(table[0][0]==table[0][1]&&table[0][1]==table[0][2]&table[0][2]==table[0][3]
                &&table[0][0]!=0&&table[0][1]!=0&&table[0][2]!=0&&table[0][3]!=0){
            //wygrana
            win=true;
        }
        if(table[1][0]==table[1][1]&&table[1][1]==table[1][2]&table[1][2]==table[1][3]
                &&table[1][0]!=0&&table[1][1]!=0&&table[1][2]!=0&&table[1][3]!=0){
            //wygrana
            win=true;
        }
        if(table[2][0]==table[2][1]&&table[2][1]==table[2][2]&table[2][2]==table[2][3]
                &&table[2][0]!=0&&table[2][1]!=0&&table[2][2]!=0&&table[2][3]!=0){
            //wygrana
            win=true;
        }
        if(table[3][0]==table[3][1]&&table[3][1]==table[3][2]&table[3][2]==table[3][3]
                &&table[3][0]!=0&&table[3][1]!=0&&table[3][2]!=0&&table[3][3]!=0){
            //wygrana
            win=true;
        }
        if(table[0][0]==table[1][0]&&table[1][0]==table[2][0]&table[2][0]==table[3][0]
                &&table[0][0]!=0&&table[1][0]!=0&&table[2][0]!=0&&table[3][0]!=0){
            //wygrana
            win=true;
        }
        if(table[0][1]==table[1][1]&&table[1][1]==table[2][1]&table[2][1]==table[3][1]
                &&table[0][1]!=0&&table[1][1]!=0&&table[2][1]!=0&&table[3][1]!=0){
            //wygrana
            win=true;
        }
        if(table[0][2]==table[1][2]&&table[1][2]==table[2][2]&table[2][2]==table[3][2]
                &&table[0][2]!=0&&table[1][2]!=0&&table[2][2]!=0&&table[3][2]!=0){
            //wygrana
            win=true;
        }
        if(table[0][3]==table[1][3]&&table[1][3]==table[2][3]&table[2][3]==table[3][3]
                &&table[0][3]!=0&&table[1][3]!=0&&table[2][3]!=0&&table[3][3]!=0){
            //wygrana
            win=true;
        }

        return win;

    }
}
