Kompilator JFiTT 2016
Miłosz Kruczyński 218381

JAK URUCHOMIC?

wywołać polecenie "make program", by skompilować. 
Następnie uruchamiamy kompilator za pomocą polecenia "./program < <nazwa_pliku_wejsciowego>"

Przykład: "./program < myprogram.imp"

kompilator powinien wygenerować plik wyjściowy "output.txt", który podajemy jako parametr do interpretera.

Przykład uruchomienia interpretera: "./interpreter  output.txt"

Przyjęte założenia:

1. Iterator w pętli "FOR" nie może mieć takiej samej nazwy, jak zmienna globalna
Przykład:
VAR
	a 
BEGIN
	FOR a FROM 0 TO 5 DO
		WRITE a;
	ENDFOR
END
Taki program wyrzuca błąd.
2. W kompilatorze nie jest sprawdzane, czy tablica postaci tab[idetifier] jest już zainicjowana.
Przykład1:
VAR
	tab[10] a
BEGIN
	a := 5;
	WRITE tab[a] ;
END
Program zostanie skompilowany
Przykład2:
VAR
	tab[10] a
BEGIN

	WRITE tab[5] ;
END
Kompilator wyrzuca bład


